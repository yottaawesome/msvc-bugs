module module_a:partition;

// Comment and uncomment this line and observe how the build 
// output states the following, suggesting only module_a is 
// getting recompiled as expected:
//		1>Target ClCompile:
//		1>  Compiling...
//		1>  module_a-partition.cpp
int z = 4;
