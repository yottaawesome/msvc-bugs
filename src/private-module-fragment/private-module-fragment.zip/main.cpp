import module_b;

int main()
{
	return 0;
}
