import std;
import somemodule;

int main()
{
    TestSettable = "a";
    return 0;
}