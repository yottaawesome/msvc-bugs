import somemodule;

int main()
{
	SomeNamespace::SomeSubclass instance{};
	return 0;
}
