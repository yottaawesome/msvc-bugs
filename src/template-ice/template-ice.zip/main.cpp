template<typename V, template<typename T>>
void Func() {}

int main()
{
	return 0;
}
