// Uncomment this include to fix the error,
// you can also use <memory> instead of
// <string>.
// Other alternatives don't appear to work,
// including importing <string>, exporting it
// from testmodule, or testmodule using and 
// exporting memcpy_s.
//#include <string>
import testmodule;

int main()
{
	JSON::JsonObject root;
	return 0;
}