import std;

int main()
{
	return 0;
}
