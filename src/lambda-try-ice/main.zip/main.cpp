import std;
import somemodule;

int main()
{
}
